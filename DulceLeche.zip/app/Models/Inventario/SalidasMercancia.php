<?php

namespace App\Models\Inventario;

use App\Livewire\Bodegas\Bodega;
use App\Models\Productos\Producto;
use App\Models\Ruta\Ruta;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class SalidasMercancia extends Model
{
   protected $table = 'salidas_mercancia';

    protected $fillable = [
        'ruta_id',
        'producto_id',
        'bodega_id',
        'cantidad',
        'fecha_salida',
        'user_id',
    ];

    public function ruta() { return $this->belongsTo(Ruta::class); }
    public function producto() { return $this->belongsTo(Producto::class); }
    public function bodega() { return $this->belongsTo(Bodega::class); }
    public function usuario() { return $this->belongsTo(User::class, 'user_id'); }
}
