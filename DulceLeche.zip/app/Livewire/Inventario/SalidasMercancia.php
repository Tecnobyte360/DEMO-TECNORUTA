<?php

namespace App\Livewire\Inventario;

use App\Models\Inventario\SalidasMercancia as InventarioSalidasMercancia;
use Livewire\Component;
use App\Models\Ruta\Ruta;
use App\Models\InventarioRuta\InventarioRuta;

use App\Models\ProductoBodega;
use Illuminate\Support\Facades\Auth;

class SalidasMercancia extends Component
{
    public $rutas = [];
    public $rutaSeleccionada = null;
    public $inventario = [];

    public function mount()
    {
        $usuarioId = Auth::id();

        $this->rutas = Ruta::whereDate('fecha_salida', now())
            ->whereHas('conductores', function ($query) use ($usuarioId) {
                $query->where('users.id', $usuarioId);
            })
            ->with('vehiculo')
            ->get();
    }

    public function updatedRutaSeleccionada()
    {
        $this->cargarInventario();
    }

    public function cargarInventario()
    {
        if (!$this->rutaSeleccionada) {
            $this->inventario = [];
            return;
        }

        $this->inventario = InventarioRuta::where('ruta_id', $this->rutaSeleccionada)
            ->with(['producto', 'bodega'])
            ->get()
            ->map(function ($item) {
                return [
                    'producto_id' => $item->producto_id,
                    'producto'    => $item->producto->nombre ?? '-',
                    'bodega'      => $item->bodega->nombre ?? '-',
                    'cantidad'    => $item->cantidad,
                    'bodega_id'   => $item->bodega_id,
                ];
            })
            ->toArray();
    }

    public function registrarSalida()
    {
        if (!$this->rutaSeleccionada || empty($this->inventario)) {
            session()->flash('error', 'Debe seleccionar una ruta con inventario.');
            return;
        }

        foreach ($this->inventario as $item) {
            // Verifica si ya existe una salida para esta ruta/producto/bodega
            $yaExiste = InventarioSalidasMercancia::where('ruta_id', $this->rutaSeleccionada)
                ->where('producto_id', $item['producto_id'])
                ->where('bodega_id', $item['bodega_id'])
                ->exists();

            if ($yaExiste) {
                continue;
            }

            // Validar stock en la bodega
            $productoBodega = ProductoBodega::where('producto_id', $item['producto_id'])
                ->where('bodega_id', $item['bodega_id'])
                ->first();

            if (!$productoBodega || $productoBodega->stock < $item['cantidad']) {
                session()->flash('error', 'Stock insuficiente para el producto: ' . $item['producto']);
                continue;
            }

            // Registrar salida
            SalidasMercancia::create([
                'ruta_id'      => $this->rutaSeleccionada,
                'producto_id'  => $item['producto_id'],
                'bodega_id'    => $item['bodega_id'],
                'cantidad'     => $item['cantidad'],
                'fecha_salida' => now(),
                'user_id'      => Auth::id(),
            ]);

            // Descontar stock
            $productoBodega->decrement('stock', $item['cantidad']);
        }

        session()->flash('success', 'Salida de mercancía registrada.');
        $this->rutaSeleccionada = null;
        $this->inventario = [];
    }

    public function render()
    {
        return view('livewire.inventario.salidas-mercancia');
    }
}
