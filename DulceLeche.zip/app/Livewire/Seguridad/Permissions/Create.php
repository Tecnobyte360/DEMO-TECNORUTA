<?php

namespace App\Livewire\Seguridad\Permissions;

use Livewire\Component;

class Create extends Component
{
    public function render()
    {
        return view('livewire.seguridad.permissions.create');
    }
}
