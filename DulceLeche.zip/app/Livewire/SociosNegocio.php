<?php

namespace App\Livewire;

use Livewire\Component;

class SociosNegocio extends Component
{
    public function render()
    {
        return view('livewire.socios-negocio');
    }
}
