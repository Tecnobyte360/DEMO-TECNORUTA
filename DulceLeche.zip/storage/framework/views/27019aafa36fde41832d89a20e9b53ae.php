<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn bg-gray-900 text-gray-100 hover:bg-gray-800 dark:bg-gray-100 dark:text-gray-800 dark:hover:bg-white whitespace-nowrap'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\DulceLeche\resources\views/components/button.blade.php ENDPATH**/ ?>