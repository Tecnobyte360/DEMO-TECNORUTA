<div class="p-6 bg-white dark:bg-gray-900 rounded-2xl shadow-2xl space-y-8">

    
    <div>
        <nav class="flex space-x-6 border-b-2 border-gray-200 dark:border-gray-700">
            <button
                wire:click="$set('tab', 'entradas')"
                class="py-2 px-4 text-sm font-bold focus:outline-none <?php echo e($tab === 'entradas' ? 'border-b-4 border-violet-600 text-violet-600' : 'text-gray-600 dark:text-gray-400 hover:text-violet-600'); ?>"
            >
                ➡️ Entradas Mercancía
            </button>

            <button
                wire:click="$set('tab', 'listado')"
                class="py-2 px-4 text-sm font-bold focus:outline-none <?php echo e($tab === 'listado' ? 'border-b-4 border-violet-600 text-violet-600' : 'text-gray-600 dark:text-gray-400 hover:text-violet-600'); ?>"
            >
                📜 Salidas Mercancia
            </button>
        </nav>
    </div>

    
    <div class="mt-6">
        <!--[if BLOCK]><![endif]--><?php if($tab === 'entradas'): ?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('inventario.entradas-mercancia', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3383043376-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php elseif($tab === 'listado'): ?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('inventario.lista-entradas-mercancia', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3383043376-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\DulceLeche\resources\views/livewire/operaciones-stock/operaciones-stock.blade.php ENDPATH**/ ?>