<form wire:submit.prevent="save">
    <div>
        <label for="nombre" class="block text-sm font-medium text-gray-700">Nombre</label>
        <input type="text" id="nombre" wire:model="nombre" class="mt-1 block w-full p-2 border rounded" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div>
        <label for="ubicacion" class="block text-sm font-medium text-gray-700">Ubicación</label>
        <input type="text" id="ubicacion" wire:model="ubicacion" class="mt-1 block w-full p-2 border rounded" />
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['ubicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="mt-2">
        <label for="activo" class="inline-flex items-center">
            <input type="checkbox" id="activo" wire:model="activo" class="form-checkbox h-5 w-5 text-indigo-600" />
            <span class="ml-2">Activo</span>
        </label>
    </div>

    <div class="mt-4 flex justify-end">
        <button type="submit" class="px-4 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600">
            Guardar Cambios
        </button>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\DulceLeche\resources\views/livewire/bodegas/edit.blade.php ENDPATH**/ ?>