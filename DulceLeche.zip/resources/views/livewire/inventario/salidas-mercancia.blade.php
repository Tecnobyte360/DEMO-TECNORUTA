<div class="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-xl">
    <h2 class="text-xl font-bold mb-4 text-gray-700 dark:text-white">Registrar Salida de Mercancía</h2>

    {{-- Selector de rutas --}}
    <div class="mb-4">
        <label class="block text-sm font-semibold text-gray-600 dark:text-gray-300">Selecciona una ruta:</label>
        <select wire:model="rutaSeleccionada"
                class="w-full mt-1 p-2 rounded-md border dark:bg-gray-700 dark:text-white">
            <option value="">-- Selecciona --</option>
            @foreach($rutas as $ruta)
                <option value="{{ $ruta->id }}">
                    {{ $ruta->ruta }} ({{ $ruta->vehiculo->placa ?? 'Sin vehículo' }})
                </option>
            @endforeach
        </select>
    </div>

    {{-- Inventario de la ruta --}}
    @if($inventario)
        <div class="mb-4 space-y-2">
            <h3 class="text-md font-semibold text-gray-700 dark:text-white">Inventario:</h3>
            @foreach($inventario as $item)
                <div class="flex justify-between bg-gray-100 dark:bg-gray-700 p-3 rounded-md text-sm">
                    <span>{{ $item['producto'] }}</span>
                    <span class="text-gray-500">{{ $item['bodega'] }}</span>
                    <span class="font-bold text-violet-600">{{ $item['cantidad'] }}</span>
                </div>
            @endforeach
        </div>

        {{-- Botón registrar --}}
        <div class="text-right">
            <button wire:click="registrarSalida"
                class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg shadow transition">
                Registrar Salida
            </button>
        </div>
    @endif

    {{-- Mensajes --}}
    @if (session()->has('success'))
        <div class="mt-4 text-green-600 font-semibold">{{ session('success') }}</div>
    @endif
    @if (session()->has('error'))
        <div class="mt-4 text-red-600 font-semibold">{{ session('error') }}</div>
    @endif
</div>
